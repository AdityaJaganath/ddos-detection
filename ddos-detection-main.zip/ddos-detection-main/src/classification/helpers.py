# Setting the dataset size to a constant which makes it simpler to fine-tune the parameters
DATASET_SIZE = 400000